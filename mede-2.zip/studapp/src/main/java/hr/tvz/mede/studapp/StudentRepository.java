package hr.tvz.mede.studapp;

import java.util.List;
import java.util.Optional;

interface StudentRepository {
    List<Student> findAll();
    Optional<Student> findStudentByJMBAG(String JMBAG);
    Optional<Student> save(StudentCommand command);
    void deleteByJMBAG(String jmbag);
}
