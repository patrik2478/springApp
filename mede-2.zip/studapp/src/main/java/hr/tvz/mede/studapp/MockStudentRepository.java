package hr.tvz.mede.studapp;

import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.*;

@Repository
public class MockStudentRepository implements StudentRepository {

    private final List<Student> MOCKED_STUDENTS = new ArrayList<>(Arrays.asList(
            new Student("Patrik", "Mede", LocalDate.now().minusYears(24),"01302953678",120),
            new Student("Marko", "Prtenjaca", LocalDate.now().minusYears(29),"0113376969",119)
            ));

    @Override
    public List<Student> findAll() {
        return MOCKED_STUDENTS;
    }

    @Override
    public Optional<Student> findStudentByJMBAG(String JMBAG) {
        Optional<Student> optionalStudent = MOCKED_STUDENTS.stream().filter(it -> Objects.equals(it.getJMBAG(), JMBAG)).findAny();
        return optionalStudent;
    }

    @Override
        public Optional<Student> save(StudentCommand command) {
        boolean exists = false;
        Student student = new Student(command.getName(), command.getSurname(), command.getDateOfBirth(), command.getJMBAG(), command.getEctsPoints());
        Optional<Student> optionalStudent = Optional.empty();

        for (int i = 0; i < MOCKED_STUDENTS.size(); i++) {
            if (MOCKED_STUDENTS.get(i).getJMBAG().equals(command.getJMBAG())) {
                exists = true;
                break;
            }
        }

        if (exists == false) {
            MOCKED_STUDENTS.add(student);
             optionalStudent = Optional.of(student);
        }
        return optionalStudent;
    }


    @Override
    public void deleteByJMBAG(String jmbag) {
       MOCKED_STUDENTS.removeIf(it -> Objects.equals(jmbag,it.getJMBAG()));
    }


}
