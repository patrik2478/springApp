package hr.tvz.mede.studapp;

import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Repository
public class MockStudentRepository implements StudentRepository {

    private final List<Student> MOCKED_STUDENTS = Arrays.asList(
            new Student("Patrik", "Mede", LocalDate.now().minusYears(24),"01302953678",120),
            new Student("Marko", "Prtenjaca", LocalDate.now().minusYears(29),"0113376969",119)
            );

    @Override
    public List<Student> findAll() {
        return MOCKED_STUDENTS;
    }

    @Override
    public Optional<Student> findStudentByJMBAG(String JMBAG) {
        return MOCKED_STUDENTS.stream().filter(it -> Objects.equals(it.getJMBAG(), JMBAG)).findAny();
    }
}
